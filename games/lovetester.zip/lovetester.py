import random
import json
random.seed()
tajny = open("poop.txt", "r")
database = json.loads(tajny.read())
tajny.close()
print("sprawdź jak sie kochaja ludzie lol")
input1=input()
input2=input()
found = 0
if not input1 + input2 in database:
    found = random.randint(0,100)
    tajny = open("poop.txt", "w")
    database[input1 + input2] = found
    tajny.write(json.dumps(database))
    tajny.close()
else:
    found = database[input1 + input2]
print(found)
input()